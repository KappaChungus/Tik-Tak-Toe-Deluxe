import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class PausePanel extends JPanel {
    private JPanel menu;
    private JPanel mainPanel;
    private CardLayout cardLayout;
    private static PausePanel instance;

    public PausePanel(CardLayout cardLayout, JPanel mainPanel) {
        instance = this;
        this.cardLayout = cardLayout;
        this.mainPanel = mainPanel;
        setBackground(Color.BLACK);
        setLayout(new BorderLayout());

        JPanel centerPanel = new JPanel(new GridBagLayout()); // Use GridBagLayout to center the content
        centerPanel.setOpaque(false); // Make the panel transparent

        menu = new JPanel(new BorderLayout()) {
            @Override
            public Dimension getPreferredSize() {
                return getSize();
            }
        };
        menu.setBackground(Color.GREEN);

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                Dimension size = centerPanel.getSize();
                int minSize = (int) Math.min(750, 0.75 * Math.min(size.width, size.height));
                menu.setSize(new Dimension(minSize, minSize));
                revalidate();
                repaint();
            }
        });

        centerPanel.add(menu); // Add the menu panel to the center panel

        add(centerPanel, BorderLayout.CENTER);
        createTextLabel();
        createButtons();
    }

    private void createTextLabel() {
        JLabel label = new JLabel("SAVE GAME?");
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 40)); // Set a larger font for the label
        label.setBorder(BorderFactory.createEmptyBorder(40, 0, 20, 0)); // Add space above and below the label
        label.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int newSize = label.getWidth()/12;
                label.setBorder(BorderFactory.createEmptyBorder(newSize, 0, newSize/2, 0)); // Add space above and below the label
                label.setFont(new Font("Arial", Font.BOLD, newSize)); // Set a larger font for the label
                label.revalidate();
                label.repaint();
            }
        });
        // Add the label to the top of the menu panel
        menu.add(label, BorderLayout.NORTH);
    }

    private void createButtons() {
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        buttonPanel.setOpaque(false);
        JButton yesButton = UIButtonFactory.createJButton("YES");
        yesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogType(JFileChooser.SAVE_DIALOG);
                int returnValue = fileChooser.showSaveDialog(null);

                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    try {
                        String gameFile = BoardPanel.getInstance().toString();
                        FileWriter writer = new FileWriter(selectedFile);
                        writer.write(gameFile);
                        writer.close();
                        cardLayout.removeLayoutComponent(GamePanel.getInstance());
                        BoardPanel.getInstance().closeSocket();
                        cardLayout.show(mainPanel, "menu");
                    } catch (IOException exception) {
                        System.err.println("Failed to save the game: " + exception.getMessage());
                    }
                }
            }
        });

        JButton noButton = UIButtonFactory.createJButton("NO");
        noButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.removeLayoutComponent(GamePanel.getInstance());
                BoardPanel.getInstance().closeSocket();
                cardLayout.show(mainPanel, "menu");
            }
        });

        JButton backToGameButton = UIButtonFactory.createJButton("BACK TO GAME");
        backToGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "game");
            }
        });

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10); // Padding around buttons
        gbc.anchor = GridBagConstraints.CENTER; // Center the buttons horizontally and vertically
        buttonPanel.add(yesButton, gbc);

        gbc.gridy = 1;
        buttonPanel.add(noButton, gbc);
        gbc.gridy = 2;
        buttonPanel.add(backToGameButton, gbc);

        buttonPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int buttonSize = (int) (buttonPanel.getHeight() * 0.18); // Use the height of botPanel as the button size
                yesButton.setPreferredSize(new Dimension(buttonSize * 5, buttonSize)); // Set preferred size of quitButton
                noButton.setPreferredSize(new Dimension(buttonSize * 5, buttonSize)); // Set preferred size of quitButton
                backToGameButton.setPreferredSize(new Dimension(buttonSize * 5, buttonSize)); // Set preferred size of quitButton
                buttonPanel.revalidate();
                buttonPanel.repaint();
            }

        });

        // Add the button panel to the center of the menu panel
        menu.add(buttonPanel, BorderLayout.CENTER);
    }

    public static PausePanel getInstance() {
        return instance;
    }

}
