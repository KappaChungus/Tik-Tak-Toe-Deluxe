import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class GamePanel extends JPanel {
    private JLabel statusLabel;
    private final String gameFile;
    private final CardLayout cardLayout;
    private final JPanel mainPanel;
    private JButton quitButton;
    private final GameMode gameMode;
    private MyScrollPane gameLogPane;
    private static GamePanel instance;
    private JPanel rightPanel;
    private JPanel topPanel;
    private JPanel botPanel;
    private final Element player;
    GamePanel(CardLayout cardLayout,
              JPanel mainPanel,
              String gameFile,
              GameMode gameMode,
              Element player) {
        instance = this;
        this.cardLayout = cardLayout;
        this.mainPanel = mainPanel;
        this.gameFile = gameFile;
        this.gameMode = gameMode;
        this.player = player;
        setBackground(Color.BLACK);
        setLayout(new BorderLayout());
        createStatusPanel();
        createGameLogPanel();
        createBoardPanel();
        createQuitPanel();
        setVisible(true);
        setPreferredSize(mainPanel.getSize());

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int width = getSize().width;
                int height = getSize().height;
                rightPanel.setPreferredSize(new Dimension(width / 5, 0)); // Update rightPanel's width
                botPanel.setPreferredSize(new Dimension(0, height / 10));
                topPanel.setPreferredSize(new Dimension(0, height / 10));
            }
        });

    }

    private void createStatusPanel() {
        topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        topPanel.setOpaque(false); // Make the panel transparent
        statusLabel = new JLabel(
                "<html><font color='red'>X</font> to move</html>"
        );
        statusLabel.setFont(new Font("Arial", Font.BOLD, 40));
        statusLabel.setForeground(Color.WHITE); // Set the text color to white
        topPanel.add(statusLabel);
        topPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int newSize = (int) (topPanel.getHeight() * 0.7);
                statusLabel.setFont(new Font("Arial", Font.BOLD, newSize)); // Set a larger font for the label
                revalidate();
            }
        });
        add(topPanel, BorderLayout.NORTH);
    }

    private void createBoardPanel() {
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(false);
        JPanel boardPanel;
        boardPanel = new BoardPanel(centerPanel,gameFile, statusLabel, gameLogPane,player);

        // Configure GridBagConstraints to center the boardPanel
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 0, 0); // Optional: Adjust insets as needed
        gbc.anchor = GridBagConstraints.CENTER;

        centerPanel.add(boardPanel, gbc);
        add(centerPanel,BorderLayout.CENTER);

    }

    private void createQuitPanel() {
        botPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        botPanel.setOpaque(false); // Make the panel transparent

        // Add a component listener to the botPanel for component resize events
        botPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int buttonSize = (int) (botPanel.getHeight() * 0.8); // Use the height of botPanel as the button size
                quitButton.setPreferredSize(new Dimension(buttonSize * 4, buttonSize)); // Set preferred size of quitButton
                botPanel.revalidate(); // Revalidate botPanel to update layout
            }
        });

        quitButton = UIButtonFactory.createJButton("QUIT"); // Create the quitButton
        quitButton.addActionListener(e -> {
            if (PausePanel.getInstance() == null)
                mainPanel.add("pausePanel", new PausePanel(cardLayout, mainPanel));
            cardLayout.show(mainPanel, "pausePanel");
        });

        botPanel.add(quitButton); // Add quitButton to botPanel
        add(botPanel, BorderLayout.SOUTH); // Add botPanel to the BorderLayout, SOUTH position
    }

    private void createGameLogPanel() {
        rightPanel = new JPanel(new BorderLayout());
        gameLogPane = new MyScrollPane();

        // Add gameLogPane to rightPanel
        rightPanel.add(gameLogPane, BorderLayout.CENTER);

        // Add a component listener to rightPanel to handle resizing
        rightPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                // Get the size of the rightPanel
                Dimension size = rightPanel.getSize();
                // Adjust the size of gameLogPane to match rightPanel
                gameLogPane.setPreferredSize(size);
            }
        });

        // Add rightPanel to the main panel (assuming this is the GamePanel)
        add(rightPanel, BorderLayout.EAST);
    }


    public static GamePanel getInstance() {
        return instance;
    }

    public GameMode getMode() {
        return gameMode;
    }
}

