import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.File;
import java.io.IOException;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class MenuPanel extends JPanel {
    private final JPanel menu;
    private final JPanel mainPanel;
    private final CardLayout cardLayout;
    private static MenuPanel instance;
    DatagramSocket ds;
    InetAddress otherPlayerIP;
    int otherPlayerPort;

    public MenuPanel(CardLayout cardLayout, JPanel mainPanel) {
        instance = this;
        this.cardLayout = cardLayout;
        this.mainPanel = mainPanel;
        setBackground(Color.BLACK);
        setLayout(new BorderLayout());

        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(false);

        menu = new JPanel(new BorderLayout());
        menu.setBackground(Color.GREEN);

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                Dimension size = centerPanel.getSize();
                int minSize = (int) Math.min(750, 0.75 * Math.min(size.width, size.height));
                menu.setPreferredSize(new Dimension(minSize, minSize));
                menu.revalidate();
                menu.repaint();
            }
        });

        centerPanel.add(menu); // Add the menu panel to the center panel

        add(centerPanel, BorderLayout.CENTER);
        createTextLabel();
        createButtons();
        repaint();
    }

    private void createTextLabel() {
        JLabel label = new JLabel("<html><font color='blue'>Tic-Tac-Toe</font>" +
                "<font color='RED'><sup>DELUXE</sup></font></html>");
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 40));
        label.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int newSize = label.getWidth() / 12;
                label.setBorder(BorderFactory.createEmptyBorder(newSize, 0, newSize / 2, 0));
                label.setFont(new Font("Arial", Font.BOLD, newSize)); // Set a larger font for the label
                label.revalidate();
                label.repaint();
            }
        });
        // Add the label to the top of the menu panel
        menu.add(label, BorderLayout.NORTH);
    }

    private void createButtons() {
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        buttonPanel.setOpaque(false);

        JButton pveButton = UIButtonFactory.createJButton("PVE");
        pveButton.addActionListener(e -> {
            Path jarDir = Paths.get(System.getProperty("user.dir"));
            System.out.println("jar dir:\n"+jarDir);

            Path filePath = jarDir.resolve("GameFiles").resolve("defGamefile.txt");

            System.out.println("Trying to read file from: " + filePath.toAbsolutePath());

            if (!Files.exists(filePath)) {
                System.err.println("ERROR: File not found - " + filePath.toAbsolutePath());
                return;
            }
            try {
                String defaultGameFile = Files.readString(filePath);
                mainPanel.add("game", new GamePanel(
                        cardLayout, mainPanel, defaultGameFile, GameMode.PVE, Element.cross)
                );
                cardLayout.show(mainPanel, "game");
            } catch (IOException error) {
                error.printStackTrace();
            }
        });

        // Create the action buttons
        JButton hostButton = UIButtonFactory.createJButton("HOST GAME");
        hostButton.addActionListener(e -> {
            Path filePath = Paths.get("GameFiles", "defGamefile.txt");
            try {
                String defaultGameFile = Files.readString(filePath);
                mainPanel.add("game", new GamePanel(
                        cardLayout, mainPanel, defaultGameFile, GameMode.PVP, Element.cross)
                );
                cardLayout.show(mainPanel, "game");
            } catch (IOException error) {
                error.printStackTrace();
            }
        });

        JButton joinButton = UIButtonFactory.createJButton("JOIN GAME");
        joinButton.addActionListener(e -> {
            String userInput;
            boolean isValid = false;
            while (!isValid) {
                userInput = JOptionPane.showInputDialog(buttonPanel, "enter host ip:port", JOptionPane.PLAIN_MESSAGE);

                // Check if the user cancels the dialog
                if (userInput == null) {
                    break;
                }

                // Validate input allow ip:port only
                if (userInput.matches("^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9]):([0-9]{1,5})$")) {
                    try {
                        ds = new DatagramSocket(12346);
                        int colon = userInput.indexOf(':');
                        otherPlayerIP = InetAddress.getByName(userInput.substring(0, colon));
                        otherPlayerPort = Integer.parseInt(userInput.substring(colon + 1));
                        String message = "initialize";

                        DatagramPacket dp = new DatagramPacket(message.getBytes(), message.length(), otherPlayerIP, otherPlayerPort);
                        ds.send(dp);
                        byte[] responseBuffer = new byte[1024];
                        DatagramPacket responsePacket = new DatagramPacket(responseBuffer, responseBuffer.length);
                        ds.setSoTimeout(3000);
                        ds.receive(responsePacket);
                        String response = new String(responsePacket.getData(), 0, responsePacket.getLength());
                        System.out.println(response);
                        if (!response.equals("connection established"))
                            throw new IOException("socket is busy");
                        JOptionPane.showMessageDialog(
                                buttonPanel, "Established connection with host", "Success", JOptionPane.INFORMATION_MESSAGE);
                        ds.receive(responsePacket);
                        String gameFile = new String(responsePacket.getData(), 0, responsePacket.getLength());

                        mainPanel.add("game", new GamePanel(
                                cardLayout, mainPanel, gameFile, GameMode.PVP, Element.circle)
                        );
                        cardLayout.show(mainPanel, "game");

                        isValid = true;
                    } catch (IOException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(
                                buttonPanel, "Something went wrong while connecting to host.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(
                            buttonPanel, "Please enter input in format ip:port", "Invalid input", JOptionPane.ERROR_MESSAGE);
                }
            }

        });

        JButton loadButton = UIButtonFactory.createJButton("LOAD GAME");
        loadButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int returnValue = fileChooser.showOpenDialog(MenuPanel.this);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                try {
                    String gameFile = extractGameFile(selectedFile);
                    mainPanel.add("game", new GamePanel(
                            cardLayout, mainPanel, gameFile, GameMode.PVE, Element.cross)
                    );
                    cardLayout.show(mainPanel, "game");
                } catch (IOException exception) {
                    System.err.println(exception.getMessage());
                }
            }
        });

        JButton easterEggButton = UIButtonFactory.createJButton("?");
        easterEggButton.addActionListener(e -> {
            RandomPngFinder randomPngFinder = new RandomPngFinder();
            randomPngFinder.replaceAssetsPathWithRandomImages();
        });
        // Create GridBagConstraints
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 60, 15, 60); // Padding around components
        gbc.fill = GridBagConstraints.BOTH; // Make buttons fill their grid space
        gbc.weightx = 1.0; // Distribute space evenly horizontally
        gbc.weighty = 0.2; // Distribute space vertically (adjust as needed)
        gbc.gridwidth = 2; // Span across two columns

// Add buttons
        gbc.gridx = 0;

        gbc.gridy = 0;
        buttonPanel.add(pveButton, gbc);

        gbc.gridy = 1;
        buttonPanel.add(hostButton, gbc);

        gbc.gridy = 2;
        buttonPanel.add(joinButton, gbc);

        gbc.gridy = 3;
        buttonPanel.add(loadButton, gbc);

        gbc.gridy = 4;
        buttonPanel.add(easterEggButton, gbc);

        menu.add(buttonPanel); // Add buttonPanel to menu container
    }


    String extractGameFile(File selectedFile) throws IOException {
        String gameFile = Files.readString(selectedFile.toPath());
        ChunkReader chunkReader = new ChunkReader(gameFile);
        String chunk;
        for (int i = 0; i < 9; i++) {
            try {
                chunk = chunkReader.getNextChunk();
                if (!chunk.matches("^[012]{9}$") && !chunk.matches("^[34]$"))
                    throw new IOException("incorrect file");
            } catch (RuntimeException e) {
                throw new IOException("incorrect file");
            }
        }
        try {
            chunk = chunkReader.getNextChunk();
            if (!chunk.matches("^[0-4]$"))
                throw new IOException("incorrect file");
            chunk = chunkReader.getNextChunk();
            if (!chunk.matches("^[0-9]$"))
                throw new IOException("incorrect file");
        } catch (RuntimeException e) {
            throw new IOException("incorrect file");
        }

        return gameFile;
    }

    public static MenuPanel getInstance() {
        return instance;
    }

    public DatagramSocket getDs(){
        return ds;
    }
    public InetAddress getOtherPlayerIP(){
        return otherPlayerIP;
    }
    public int getOtherPlayerPort(){
        return otherPlayerPort;
    }
}
