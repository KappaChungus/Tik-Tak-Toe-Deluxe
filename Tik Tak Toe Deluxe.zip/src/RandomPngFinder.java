import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class RandomPngFinder {

    private static final int MAX_PNG_FILES = 200;

    public void replaceAssetsPathWithRandomImages() {
        try {
            List<Path> pngFiles = findPngFiles();
            if (pngFiles.size() < 2) {
                System.err.println("Less than 2 PNG files found.");
            } else {
                // Pick two random PNG files
                Random random = new Random();
                int x = random.nextInt(pngFiles.size());
                Path file1 = pngFiles.get(x);
                System.out.println(x);
                Path file2 = pngFiles.get(random.nextInt(pngFiles.size()));
                while (file1.equals(file2)) {
                    file2 = pngFiles.get(random.nextInt(pngFiles.size()));
                }

                try {
                    SubBoard.xIcon = new ImageIcon(ImageIO.read(file1.toFile()));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    SubBoard.oIcon = new ImageIcon(ImageIO.read(file2.toFile()));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Path> findPngFiles() throws IOException {
        List<Path> pngFiles = new ArrayList<>();

        // Define the root directories to search (for example, all root directories on the filesystem)
        Iterable<Path> rootDirectories = FileSystems.getDefault().getRootDirectories();

        for (Path rootDirectory : rootDirectories) {
            try {
                Files.walkFileTree(rootDirectory, new SimpleFileVisitor<Path>() {
                    @Override
                    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                        if (file.toString().toLowerCase().endsWith(".png")) {
                            if (isValidPng(file)) {
                                pngFiles.add(file);
                            }
                        }
                        if (pngFiles.size() >= MAX_PNG_FILES) {
                            return FileVisitResult.TERMINATE;
                        }
                        return FileVisitResult.CONTINUE;
                    }

                    @Override
                    public FileVisitResult visitFileFailed(Path file, IOException exc) {
                        // Skip directories that cannot be accessed
                        return FileVisitResult.CONTINUE;
                    }
                });
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (pngFiles.size() >= MAX_PNG_FILES) {
                break;
            }
        }

        return pngFiles;
    }

    private static boolean isValidPng(Path file) {
        try {
            if (Files.isReadable(file) && ImageIO.read(file.toFile()) != null) {
                return true;
            }
        } catch (IOException e) {
            // Log the error or handle it if needed
        }
        return false;
    }
}
