import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

public class SubBoard extends JPanel {

    private Color bgColor;

    private int noElements;

    private boolean active;

    public static ImageIcon xIcon;

    public static ImageIcon oIcon;
    public static String path;

    public SubBoard(String gameFile) {
        if(path == null){
            path = System.getProperty("user.dir") + "\\Assets";
        }
        if(xIcon == null){
            try {
                SubBoard.xIcon = new ImageIcon(ImageIO.read(new File(path+"\\x.png")));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if(oIcon == null){
            try {
                SubBoard.oIcon = new ImageIcon(ImageIO.read(new File(path+"\\o.png")));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        setLayout(new GridLayout(3, 3, 3, 3));
        bgColor = Color.BLACK;
        setBackground(bgColor);
        active = false;
        for (int i = 0; i < 9; i++) {
            Element element = Element.fromValue(gameFile.charAt(i)-'0');
            if (element == Element.none)
                add(new MyButton(this));
            else {
                SubBoard.replaceWithLabel(this, i, element);
                noElements++;
                BoardPanel.getInstance().setBoard(MyButton.getButtonCounter(),element);
                MyButton.incrementButtonCounter(1);
            }
        }

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (active && BoardPanel.getInstance().myTurn()) {
                    updatePanelColor(slightlyLighter(bgColor));
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (active && BoardPanel.getInstance().myTurn())
                    updatePanelColor(bgColor);
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int panelWidth = getWidth();
        int panelHeight = getHeight();

        // make square slightly smaller than this board
        int squareSize = Math.min(panelWidth, panelHeight) - 5;

        // Calculate the position to center the square
        int paddingX = (panelWidth - squareSize) / 2;
        int paddingY = (panelHeight - squareSize) / 2;

        g.setColor(Color.GREEN);
        g.fillRect(paddingX, paddingY, squareSize, squareSize);
    }

    public void updatePanelColor(Color color) {
        setBackground(color);
        Component[] components = getComponents();
        for (Component component : components) {
            if (component instanceof JButton) {
                component.setBackground(color);
            }
        }
        repaint();
    }

    public static void replaceWithLabel(JPanel panel, int index, Element element) {
        if (index < panel.getComponentCount()) {
            panel.remove(index);
        }

        ImageIcon imageIcon = (element == Element.circle) ? oIcon : xIcon;
        JLabel imageLabel = new JLabel(getResizedIcon(
                imageIcon,
                panel.getWidth(),
                panel.getHeight()
        ));
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imageLabel.setVerticalAlignment(SwingConstants.CENTER);
        imageLabel.setPreferredSize(panel.getPreferredSize());
        imageLabel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                imageLabel.setIcon(getResizedIcon(
                        imageIcon,
                        imageLabel.getWidth(),
                        imageLabel.getHeight())
                );

                imageLabel.revalidate();
                imageLabel.repaint();
            }
        });

        panel.add(imageLabel, index);
        panel.revalidate();
        panel.repaint();
    }

    public static ImageIcon getResizedIcon(ImageIcon imageIcon,
                                           int width, int height){
        Image img = imageIcon.getImage();
        Image resizedImage = img.getScaledInstance(
                Math.max(1,width), Math.max(1,height),
                Image.SCALE_SMOOTH
        );
        return new ImageIcon(resizedImage);
    }

    public static Color slightlyLighter(Color color) {
        int r = color.getRed();
        int g = color.getGreen();
        int b = color.getBlue();
        r = Math.min(r + 20, 255);
        g = Math.min(g + 20, 255);
        b = Math.min(b + 20, 255);
        return new Color(r, g, b);
    }

    private static int calculateFontSize(JPanel panel) {
        int panelSize = Math.min(panel.getWidth(), panel.getHeight());
        return panelSize / 5;
    }

    public Color getBgColor() {
        return bgColor;
    }

    public boolean isFull() {
        return noElements == 9;
    }

    public void setActive(boolean val) {
        active = val;
    }

    public boolean isActive() {
        return active;
    }

    public void setBgColor(Color color) {
        bgColor = color;
        updatePanelColor(bgColor);
        repaint();
    }
    public void incrementNoElements(){
        noElements++;
    }
}
