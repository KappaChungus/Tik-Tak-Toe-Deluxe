import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class UIButtonFactory {

    private static void styleButton(AbstractButton button, String text) {
        button.setText(text);
        button.setForeground(Color.GREEN); // Set text color to green
        button.setBackground(Color.BLACK); // Set background color to black
        button.setFocusPainted(false); // Remove focus border
        button.setUI(new BasicButtonUI() {
            @Override
            protected void paintButtonPressed(Graphics g, AbstractButton b) {
                // Do not paint the pressed state to prevent color change
            }
        });
        button.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                button.setFont(new Font(
                        "Arial",
                        Font.PLAIN,
                        (int) (0.55 * button.getHeight())
                ));
            }
        });
    }

    // Static factory method to create a JButton
    public static JButton createJButton(String text) {
        JButton button = new JButton();
        styleButton(button, text);
        return button;
    }

}
