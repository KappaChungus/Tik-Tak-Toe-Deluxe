public enum Element{
    cross (0),
    circle (1),
    none (2);
    private final int value;

    Element(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
    public static Element fromValue(int value) {
        for (Element element : Element.values()) {
            if (element.getValue() == value) {
                return element;
            }
        }
        return none; // Default case, if needed
    }
}