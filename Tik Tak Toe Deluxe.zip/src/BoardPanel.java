import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.*;
import java.util.Arrays;
import java.util.Random;

public class BoardPanel extends JPanel {
    private final Element[][] board;

    private final Element[] bigBoard;
    private static BoardPanel instance;
    private Element turn;
    private Element winner;
    private int noCompletedGames;
    private int activePanelIndex;
    private final JLabel statusLabel;
    private final MyScrollPane gameLogPane;
    private final static int boardSize = 9;
    private final static int noRows = 3;
    private final static int noColumns = 3;
    private final static int gapBetweenBoards = 5;
    private final static int notFound = -1;
    private final JPanel centerPanel;
    private final static double sizeRatio = 0.95;
    private final Element player;
    private DatagramSocket ds;
    private InetAddress otherPlayerIP;
    private int otherPlayerPort;

    BoardPanel(JPanel centerPanel,
               String gameFile,
               JLabel statusLabel,
               MyScrollPane gameLogPane,
               Element player) {
        super(new GridLayout(noRows, noColumns, gapBetweenBoards, gapBetweenBoards));
        this.statusLabel = statusLabel;
        this.gameLogPane = gameLogPane;
        this.centerPanel = centerPanel;
        this.player = player;
        instance = this;
        setBackground(Color.BLACK);
        board = new Element[boardSize][boardSize];
        bigBoard = new Element[boardSize];
        MyButton.resetButtonCounter();
        if (GamePanel.getInstance().getMode() == GameMode.PVP) {
            if (player == Element.cross) {
                try {
                    int minPort = 10001;
                    int maxPort = 65535;
                    Random random = new Random();
                    int randomPort=-1;
                    while (ds == null) {
                        randomPort = random.nextInt(maxPort - minPort + 1) + minPort;
                        try {
                            ds = new DatagramSocket(randomPort);
                        } catch (BindException e) {
                            e.printStackTrace();
                        }
                    }
                    String hostInfo = InetAddress.getLocalHost().getHostAddress()+ ":"+randomPort;

                    new Thread(() -> {
                        System.out.println(player);
                        try {
                            byte[] buf = new byte[1024];
                            DatagramPacket dp = new DatagramPacket(buf, buf.length);
                            LoadingDialog loadingDialog = new LoadingDialog(hostInfo);
                            SwingUtilities.invokeLater(() -> loadingDialog.setVisible(true));
                            ds.receive(dp);
                            String received = new String(buf, 0, 10);
                            System.out.println(received);
                            if (!received.equals("initialize")) return;
                            System.out.println("xd");
                            String responseMessage = "connection established";
                            otherPlayerIP = dp.getAddress();
                            otherPlayerPort = dp.getPort();
                            byte[] responseData = responseMessage.getBytes();
                            DatagramPacket responsePacket = new DatagramPacket(responseData, responseData.length, otherPlayerIP, otherPlayerPort);
                            ds.send(responsePacket);
                            responsePacket.setData(toString().getBytes());
                            ds.send(responsePacket);
                            System.out.println("finished");
                            loadingDialog.dispose();
                            recieveOtherPlayerMove();

                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }).start();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                ds = MenuPanel.getInstance().getDs();
                try {
                    ds.setSoTimeout(0);
                } catch (SocketException e) {
                    e.printStackTrace();
                }
                otherPlayerIP = MenuPanel.getInstance().getOtherPlayerIP();
                otherPlayerPort = MenuPanel.getInstance().getOtherPlayerPort();
                System.out.println(ds + " " + otherPlayerIP + " " + otherPlayerPort);
                new Thread(this::recieveOtherPlayerMove).start();
            }
        }
        setupContentFromGameFile(gameFile);
    }


    private void setupContentFromGameFile(String gameFile) {
        //class that reads chunk of information from string
        ChunkReader chunkReader = new ChunkReader(gameFile);

        // Add 9 sub boards to big board
        for (int i = 0; i < boardSize; i++) {
            String chunk = chunkReader.getNextChunk();
            if (chunk.length() == 1) {
                Element element = Element.fromValue(chunk.charAt(0) - '3');
                SubBoard.replaceWithLabel(this, i, element);
                noCompletedGames++;
                MyButton.incrementButtonCounter(boardSize);
                bigBoard[i] = element;
            } else {
                SubBoard panel = new SubBoard(chunk);
                add(panel);
                if (panel.isFull())
                    noCompletedGames++;
                bigBoard[i] = Element.none;
            }
        }
        int gameState = chunkReader.getNextChunk().charAt(0) - '0';
        statusLabel.setText(
                switch (gameState) {
                    case 0 -> "<html><font color='red'>X</font> to move</html>";
                    case 1 -> "<html><font color='blue'>O</font> to move</html>";
                    case 2 -> "<html><font color='red'>X</font> wins!</html>";
                    case 3 -> "<html><font color='blue'>O</font> wins!</html>";
                    case 4 -> "draw!";
                    default -> "error";
                }
        );
        if (gameState < 2) {
            turn = Element.fromValue(gameState);
            winner = Element.none;
            activePanelIndex = chunkReader.getNextChunk().charAt(0) - '0';
            if (activePanelIndex == boardSize)
                setPanelsActive(true);
            else {
                SubBoard nextPanel = ((SubBoard) getComponent(activePanelIndex));
                nextPanel.setActive(true);
                nextPanel.setBgColor(new Color(110, 60, 130));
            }
            if (GamePanel.getInstance().getMode()
                    == GameMode.PVE && turn == Element.circle)
                SwingUtilities.invokeLater(this::makeComputerMove);
        } else {
            //game is over
            turn = Element.none;
            winner = Element.fromValue(gameState - 2);
        }
    }

    @Override
    public Dimension getPreferredSize() {
        int size = (int) (
                sizeRatio *
                        Math.min(centerPanel.getWidth(), centerPanel.getHeight())
        );
        return new Dimension(size, size);
    }

    public void handleButtonClick(int buttonID, boolean notifyOtherPlayer) {
        if (GamePanel.getInstance().getMode() == GameMode.PVP && notifyOtherPlayer)
            notifyOtherPlayer(buttonID);
        int clickedPanelIndex = buttonID / boardSize;
        var clickedPanel = (SubBoard) getComponent(clickedPanelIndex);
        SubBoard.replaceWithLabel(clickedPanel, buttonID % boardSize, turn);
        clickedPanel.incrementNoElements();

        board[clickedPanelIndex][buttonID % boardSize] = turn;

        //check if sub board was completed
        Element result = checkBoard(board[clickedPanelIndex]);
        if (result != Element.none) {
            // sub game was won after button click
            bigBoard[clickedPanelIndex] = result;
            noCompletedGames++;
            SubBoard.replaceWithLabel(this, clickedPanelIndex, turn);

        } else if (((SubBoard) getComponent(clickedPanelIndex)).isFull())
            noCompletedGames++;

        // check if big Board was completed
        result = checkBoard(bigBoard);
        if (result != Element.none) {

            if (result == Element.cross) {
                winner = Element.cross;
                statusLabel.setText("<html><font color='red'>X</font> wins!</html>");
            } else {
                winner = Element.circle;
                statusLabel.setText("<html><font color='blue'>O</font> wins!</html>");
            }
            turn = Element.none;
            setPanelsActive(false);
            return;

        } else if (noCompletedGames == boardSize) {
            statusLabel.setText("draw!");
            turn = Element.none;
            return;
        }
        SwingUtilities.invokeLater(() -> {
            clickedPanel.setBgColor(Color.BLACK);
            clickedPanel.repaint();
            SwingUtilities.invokeLater(() -> {
                gameLogPane.addCapturedPanel(capturePanel());
                handleNextActivePanel(buttonID);
                if (GamePanel.getInstance().getMode() == GameMode.PVE && turn == Element.circle) {
                    makeComputerMove();
                }
            });
        });


    }

    private void handleNextActivePanel(int buttonID) {
        changeTurn();
        activePanelIndex = buttonID % boardSize;
        var nextMovePanel = getComponent(activePanelIndex);
        if (!(nextMovePanel instanceof SubBoard) || ((SubBoard) nextMovePanel).isFull()) {
            activePanelIndex = boardSize;
            Component[] components = getComponents();
            for (var component : components) {
                if (component instanceof SubBoard)
                    ((SubBoard) component).setActive(!((SubBoard) component).isFull());
            }
        } else {
            setPanelsActive(false);
            ((SubBoard) nextMovePanel).setActive(true);
            ((SubBoard) nextMovePanel).setBgColor(new Color(110, 60, 130));
        }
    }

    public void setPanelsActive(boolean val) {
        Component[] components = getComponents();
        for (var component : components) {
            if (component instanceof SubBoard)
                ((SubBoard) component).setActive(val);
        }
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int panelSize = getWidth();

        // create a square that almost fully fits board
        int squareSize = (int) (panelSize - 2);

        int paddingX = (panelSize - squareSize) / 2;
        int paddingY = (panelSize - squareSize) / 2;

        g.setColor(Color.WHITE);
        g.fillRect(paddingX, paddingY, squareSize, squareSize);
    }

    private Element checkBoard(Element[] subBoard) {
        Element result = checkRows(subBoard);
        if (result != Element.none)
            return result;
        result = checkCollumns(subBoard);
        if (result != Element.none)
            return result;
        return checkDiagonals(subBoard);
    }

    private Element checkRows(Element[] subBoard) {
        for (int i = 0; i < boardSize; i += noRows - i % noColumns) {
            do {
                if (i % noColumns == noColumns - 1)
                    return subBoard[i];
                if (subBoard[i] == Element.none ||
                        subBoard[i] != subBoard[i + 1])
                    break;
                i++;
            } while (i % noColumns != 0);

        }
        return Element.none;
    }

    private Element checkCollumns(Element[] subBoard) {
        for (int i = 0; i < noColumns; i++) {
            while (i < boardSize) {
                if (i >= boardSize - noColumns)
                    return subBoard[i];
                if (subBoard[i] == Element.none ||
                        subBoard[i] != subBoard[i + noRows])
                    break;
                i += noRows;
            }
            i = i % noRows;
        }
        return Element.none;
    }

    private Element checkDiagonals(Element[] subBoard) {
        return ((subBoard[0] != Element.none
                && (subBoard[0] == subBoard[4]
                && subBoard[4] == subBoard[8]))

                || (subBoard[2] != Element.none
                && (subBoard[2] == subBoard[4]
                && subBoard[4] == subBoard[6])
        )) ? subBoard[4] : Element.none;
    }

    public static BoardPanel getInstance() {
        return instance;
    }

    private void changeTurn() {
        if (turn == Element.cross) {
            turn = Element.circle;
            statusLabel.setText(
                    "<html><font color='blue'>O</font> to move</html>"
            );
        } else {
            turn = Element.cross;
            statusLabel.setText(
                    "<html><font color='red'>X</font> to move</html>"
            );
        }
    }

    private void makeComputerMove() {
        int goodMove = notFound;
        if (activePanelIndex < boardSize)
            goodMove = findNotLosingMoveOnSubBoard();
        else
            for (activePanelIndex = 0; activePanelIndex < boardSize; activePanelIndex++)
                if (bigBoard[activePanelIndex] == Element.none) {
                    goodMove = findNotLosingMoveOnSubBoard();
                    if (goodMove != notFound) break;
                }

        if (goodMove == notFound)
            makeRandomMove();
        else
            handleButtonClick(goodMove, false);
    }

    private int findNotLosingMoveOnSubBoard() {
        int goodMove = notFound;
        for (int i = 0; i < boardSize; i++) {
            if (board[activePanelIndex][i] != Element.none)
                continue;
            board[activePanelIndex][i] = Element.circle;

            //if there is a move that wins board make this move instantly
            if (checkBoard(board[activePanelIndex]) == Element.circle)
                return boardSize * activePanelIndex + i;

            int prevActivePanel = activePanelIndex;
            activePanelIndex = i;

            if (bigBoard[activePanelIndex] == Element.none) {
                boolean foundCounter = false;
                for (int j = 0; j < boardSize; j++) {
                    if (board[activePanelIndex][j] != Element.none) continue;
                    board[activePanelIndex][j] = Element.cross;
                    //check if cross can win board in one move after circle move
                    if (checkBoard(board[activePanelIndex]) == Element.cross) {
                        board[activePanelIndex][j] = Element.none;
                        foundCounter = true;
                        break;
                    }
                    board[activePanelIndex][j] = Element.none;
                }
                if (!foundCounter) {
                    goodMove = boardSize * prevActivePanel + i;
                }
            }
            //revert move
            activePanelIndex = prevActivePanel;
            board[activePanelIndex][i] = Element.none;
        }
        return goodMove;
    }

    private void makeRandomMove() {
        int noButtons = (boardSize * boardSize);
        // % and min are for case when activePanelIndex = 9 (all panels active)

        int lowerBound = (boardSize * activePanelIndex) % noButtons;
        int upperBound = Math.min(boardSize * (activePanelIndex + 1), noButtons);
        Random rand = new Random();
        int randomButtonID;
        // make sure button hasn't been clicked already
        do {
            randomButtonID = rand.nextInt(upperBound - lowerBound) + lowerBound;
        } while (
                board[randomButtonID / 9][randomButtonID % 9] != Element.none
                        || bigBoard[randomButtonID / 9] != Element.none
        );
        handleButtonClick(randomButtonID, false);
    }

    public void setBoard(int buttonID, Element element) {
        board[buttonID / boardSize][buttonID % boardSize] = element;
    }

    private BufferedImage capturePanel() {
        int width = getWidth();
        int height = getHeight();
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        instance.printAll(g2d);
        g2d.dispose();

        return image;
    }

    @Override
    public String toString() {
        StringBuffer result = new StringBuffer();
        for (int i = 0; i < board.length; i++) {
            if (bigBoard[i] == Element.none)
                //sub board is not won
                for (int j = 0; j < board[i].length; j++) {
                    result.append((char) (board[i][j].getValue() + '0'));
                }
            else {
                //sub board is won
                result.append((char) (bigBoard[i].getValue() + '3'));
            }
            //add guard after each board
            result.append('$');
        }
        if (turn == Element.none)
            result.append((char) (winner.getValue() + '2'));
        else
            result.append((char) (turn.getValue() + '0'));
        result.append('$');
        result.append((char) (activePanelIndex + '0'));
        result.append('$');
        return result.toString();
    }

    public boolean myTurn() {
        return turn == player;
    }

    private void notifyOtherPlayer(int buttonID) {
        byte[] buf = new byte[1];
        buf[0] = (byte) buttonID;
        System.out.println("sending" + buttonID + " to " + otherPlayerIP + " " + otherPlayerPort);
        DatagramPacket dp = new DatagramPacket(buf, 1, otherPlayerIP, otherPlayerPort);
        try {
            ds.send(dp);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void recieveOtherPlayerMove(){
        while (true) {
            byte[] buf = new byte[1];
            DatagramPacket dp = new DatagramPacket(buf, 1);
            try {
                if (ds.isClosed())
                    break;
                ds.receive(dp);
                System.out.println(dp.getData()[0] + " " + dp.getAddress() + " " + dp.getPort());
                handleButtonClick(dp.getData()[0], false);
            } catch (Exception e) {
                System.out.println("Xd");
            }
        }
    }

    public void closeSocket() {
        if(ds!=null)
            ds.close();
    }

}
