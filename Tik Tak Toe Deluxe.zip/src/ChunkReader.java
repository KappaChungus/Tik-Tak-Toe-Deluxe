public class ChunkReader {
    private int it;
    private String gameFile;
    ChunkReader(String gameFile){
        this.gameFile=gameFile;
    }
    public String getNextChunk() throws RuntimeException {
        StringBuffer result = new StringBuffer();
        char pom;
        while ((pom = gameFile.charAt(it++)) != '$') {
            result.append(pom);
            if (it == gameFile.length())
                throw new RuntimeException("invalid game file");
        }

        return result.toString();
    }
}
