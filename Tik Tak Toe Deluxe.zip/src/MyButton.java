import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.event.MouseAdapter;

public class MyButton extends JButton {
    private static int buttonCounter=0;

    public int getButtonId() {
        return buttonId;
    }

    int buttonId;
    MyButton(SubBoard subBoard) {
        super();
        buttonId = buttonCounter++;
        BoardPanel.getInstance().setBoard(buttonId,Element.none);
        setBackground(Color.BLACK);
        setBorderPainted(false);
        setFocusPainted(false);
        setPressedIcon(null);
        setUI(new BasicButtonUI() {
            @Override
            protected void paintButtonPressed(Graphics g, AbstractButton b) {
                // Do not paint the pressed state to prevent color change
            }
        });
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if(subBoard.isActive() && BoardPanel.getInstance().myTurn()) {
                    Color panelColor = subBoard.getBgColor();
                    subBoard.updatePanelColor(SubBoard.slightlyLighter(panelColor));
                    setBackground(panelColor);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if(subBoard.isActive() && BoardPanel.getInstance().myTurn()) {
                    // Revert panel color when mouse exits
                    subBoard.updatePanelColor(subBoard.getBgColor());
                }
            }


            @Override
            public void mouseReleased(MouseEvent e) {
                if(subBoard.isActive() && BoardPanel.getInstance().myTurn()) {
                    // Change the button appearance and replace it with a blank panel
                    BoardPanel.getInstance().handleButtonClick(buttonId,true);
                }
            }
        });
    }
    public static void resetButtonCounter(){
        buttonCounter = 0;
    }
    public static void incrementButtonCounter(int increment){
        buttonCounter+=increment;
    }
    public static int getButtonCounter(){
        return buttonCounter;
    }
}
