import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("TIK TAK TOE DELUXE");
            frame.setSize(750, 750);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            CardLayout cardLayout = new CardLayout();
            JPanel mainPanel = new JPanel(cardLayout);

            MenuPanel menuPanel = new MenuPanel(cardLayout, mainPanel);

            mainPanel.add(menuPanel, "menu");

            frame.add(mainPanel);
            // Center frame
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);

            // Show menu panel at startup
            cardLayout.show(mainPanel, "menu");
        });
    }
}
