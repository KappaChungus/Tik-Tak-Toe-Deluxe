import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.InetAddress;

public class LoadingDialog extends JDialog {

    LoadingDialog(String hostInfo) {
        // Create the dialog
        super();
        setTitle("Waiting");
        setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE); // Prevent user from closing
        setModal(true); // Make it modal (blocks other interactions)
        setSize(300, 150); // Set size of the dialog
        setLocationRelativeTo(null); // Center dialog on the screen

        // Create the content panel for the dialog
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // Add a label
        JLabel label = new JLabel("Waiting for another player...", JLabel.CENTER);
        panel.add(label, BorderLayout.NORTH);

        // Create the progress bar in indeterminate mode (infinite animation)
        JProgressBar progressBar = new JProgressBar();
        progressBar.setIndeterminate(true); // Set the progress bar to indeterminate mode
        progressBar.setStringPainted(false); // Remove the percentage text
        progressBar.setPreferredSize(new Dimension(250, 20)); // Set a custom size for the progress bar
        panel.add(progressBar, BorderLayout.CENTER);

        add(panel);

        JButton hostInfoButton = new JButton("Host Info");
        hostInfoButton.setPreferredSize(new Dimension(100, 30)); // Set button size
        hostInfoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Copy the host info to the clipboard
                StringSelection stringSelection = new StringSelection(hostInfo);
                Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                clipboard.setContents(stringSelection, null);

                // Show a confirmation dialog to the user
                JOptionPane.showMessageDialog(null, "Host info copied to clipboard!", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // Add the Host Info button at the bottom of the dialog
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(hostInfoButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

    }
}