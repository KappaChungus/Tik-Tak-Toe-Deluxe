import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public class MyScrollPane extends JScrollPane {
    private JPanel capturePanelContainer;
    private List<BufferedImage> originalImages = new ArrayList<>();

    public MyScrollPane() {
        setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        setPreferredSize(new Dimension(150, 500));

        // Initialize the capture panel container
        capturePanelContainer = new JPanel();
        capturePanelContainer.setBackground(Color.BLACK);
        capturePanelContainer.setLayout(new BoxLayout(capturePanelContainer, BoxLayout.Y_AXIS)); // Using BoxLayout for vertical stacking
        setViewportView(capturePanelContainer);
    }

    public void addCapturedPanel(BufferedImage image) {
        originalImages.add(image);
        JLabel capturedLabel = resizeAndCreateLabel(image);
        capturePanelContainer.add(capturedLabel);
        capturePanelContainer.add(Box.createVerticalStrut(
                capturePanelContainer.getWidth()/9)
        );

        revalidate();
        repaint();

        // Scroll to the bottom of the scroll pane
        SwingUtilities.invokeLater(() -> {
            JScrollBar verticalScrollBar = getVerticalScrollBar();
            verticalScrollBar.setValue(verticalScrollBar.getMaximum());
        });
    }

    private JLabel resizeAndCreateLabel(BufferedImage image) {
        int containerWidth = (int) (0.95 * capturePanelContainer.getWidth()); // Use a fraction of container width
        int containerHeight = (int) (0.95 * capturePanelContainer.getHeight()); // Use a fraction of container height

        // Scale the image to fit within the container width
        Image scaledImage = image.getScaledInstance(containerWidth, -1, Image.SCALE_SMOOTH);

        // Create a BufferedImage from the scaled image
        BufferedImage bufferedImage = new BufferedImage(containerWidth, scaledImage.getHeight(null), BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = bufferedImage.createGraphics();
        g2d.drawImage(scaledImage, 0, 0, null);
        g2d.dispose();

        // Create a JLabel with the scaled image
        JLabel label = new JLabel(new ImageIcon(bufferedImage));
        label.setAlignmentX(Component.CENTER_ALIGNMENT); // Center align the image horizontally

        return label;
    }

    @Override
    public void setPreferredSize(Dimension preferredSize) {
        super.setPreferredSize(preferredSize);
        adjustComponentSizes();
    }

    private void adjustComponentSizes() {
        if(capturePanelContainer!=null) {
            int containerWidth = capturePanelContainer.getWidth();
            Component[] components = capturePanelContainer.getComponents();

            for (int i = 0; i < components.length; i++) {
                Component component = components[i];
                if (component instanceof JLabel) {
                    BufferedImage originalImage = originalImages.get(i / 2);
                    JLabel resizedLabel = resizeAndCreateLabel(originalImage);

                    // Replace the old JLabel with the new one
                    capturePanelContainer.remove(component);
                    capturePanelContainer.add(resizedLabel, i);
                }
                else{
                    capturePanelContainer.remove(component);
                    capturePanelContainer.add(Box.createVerticalStrut(
                            capturePanelContainer.getWidth()/9), i
                    );
                }
            }

            SwingUtilities.invokeLater(() -> {
                JScrollBar verticalScrollBar = getVerticalScrollBar();
                verticalScrollBar.setValue(verticalScrollBar.getMaximum());
            });
            capturePanelContainer.revalidate();
            capturePanelContainer.repaint();
        }
    }
}
